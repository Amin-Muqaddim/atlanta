<?php global $events_calendar_filter; ?><div id="integration-events-calendar" class="emd-container emd-integration-wrap">
<?php echo do_shortcode("[emd_calendar app='wp-easy-events' cname='event_calendar']"); ?>
</div><!--container-end-->