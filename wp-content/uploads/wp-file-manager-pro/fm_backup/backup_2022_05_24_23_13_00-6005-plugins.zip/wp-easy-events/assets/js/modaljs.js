jQuery(document).ready(function($){
        $('a[rel*=leanModal]').leanModal({ top : 50, overlay : 0.4, closeButton: ".modal_close" });
});