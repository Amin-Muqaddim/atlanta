jQuery(document).ready(function($){
        $(this).setFeedback(wp_easy_events_vars.plugin);
});
